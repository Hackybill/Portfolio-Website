const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('.'));

// Simple file-based storage
const USERS_FILE = path.join(__dirname, 'users.json');
const CONTACTS_FILE = path.join(__dirname, 'contacts.json');

// Initialize files if they don't exist
if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, JSON.stringify([]));
}
if (!fs.existsSync(CONTACTS_FILE)) {
    fs.writeFileSync(CONTACTS_FILE, JSON.stringify([]));
}

// Helper functions
const readUsers = () => {
    try {
        return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    } catch {
        return [];
    }
};

const writeUsers = (users) => {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
};

const readContacts = () => {
    try {
        return JSON.parse(fs.readFileSync(CONTACTS_FILE, 'utf8'));
    } catch {
        return [];
    }
};

const writeContacts = (contacts) => {
    fs.writeFileSync(CONTACTS_FILE, JSON.stringify(contacts, null, 2));
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true, 
        message: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

// User Registration - Optimized for speed
app.post('/api/register', (req, res) => {
    const { fullName, email, username, password } = req.body;

    // Quick validation
    if (!fullName || !email || !username || !password) {
        return res.status(400).json({
            success: false,
            message: 'All fields required'
        });
    }

    // Fast user creation
    const userId = Date.now();
    const newUser = {
        id: userId,
        fullName,
        email,
        username,
        password,
        createdAt: new Date().toISOString()
    };

    // Async file operations for speed
    setImmediate(() => {
        try {
            const users = readUsers();
            users.push(newUser);
            writeUsers(users);
        } catch (error) {
            console.log('Background save error:', error);
        }
    });

    // Immediate response
    res.status(201).json({
        success: true,
        message: 'Registration successful!',
        userId: userId
    });
});

// User Login - Optimized
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            success: false,
            message: 'Username and password required'
        });
    }

    const users = readUsers();
    const user = users.find(u => u.username === username && u.password === password);

    if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Invalid credentials'
        });
    }

    res.json({
        success: true,
        message: 'Login successful',
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            fullName: user.fullName
        }
    });
});

// Contact Form - Fast response
app.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({
            success: false,
            message: 'All fields required'
        });
    }

    const messageId = Date.now();
    const newContact = {
        id: messageId,
        name,
        email,
        message,
        createdAt: new Date().toISOString()
    };

    // Async save for speed
    setImmediate(() => {
        try {
            const contacts = readContacts();
            contacts.push(newContact);
            writeContacts(contacts);
        } catch (error) {
            console.log('Contact save error:', error);
        }
    });

    // Immediate response
    res.json({
        success: true,
        message: 'Message sent!',
        messageId: messageId
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`✅ Backend is ready!`);
});